# PythonLib

Pacote Python básico
https://github.com/luizasilveira/dev-aberto
